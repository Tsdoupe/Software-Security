package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ChecksumController {
	// Add route to return checksum of static data
	@GetMapping("/hash")
	public String getHash() throws NoSuchAlgorithmException {
		String data = "My special string - Tyler Doupe";
		
		// Generate SHA-256 checksum for the data
		String checksum = generateChecksum(data);
		
		return "Data: " + data + "<br>Checksum (SHA-256): " + checksum;
	}
	
	// Helper method to generate SHA-256 checksum
	private String generateChecksum(String data) throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hash = digest.digest(data.getBytes());
		StringBuilder hexString = new StringBuilder();
		
		for (byte b : hash) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		
		return hexString.toString();
	}
}